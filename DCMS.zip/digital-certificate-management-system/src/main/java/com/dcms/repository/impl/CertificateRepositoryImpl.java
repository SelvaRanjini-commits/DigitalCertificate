package com.dcms.repository.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dcms.model.Certificate;
import com.dcms.repository.CertificateRepository;
import com.dcms.util.DBConnection;

public class CertificateRepositoryImpl implements CertificateRepository {

    @Override
    public void insertCertificate(Certificate c) {
        String sql = "INSERT INTO certificates (studentName, courseName, issueDate, status) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getStudentName());
            ps.setString(2, c.getCourseName());
            ps.setDate(3, Date.valueOf(c.getIssueDate()));
            ps.setString(4, c.getStatus());
            ps.executeUpdate();
            System.out.println("INSERTED Successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Certificate> getAllCertificates() {
        List<Certificate> list = new ArrayList<>();
        String sql = "SELECT * FROM certificates";
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Certificate cert = new Certificate();
                cert.setCertificateId(rs.getInt("certificateId"));
                cert.setStudentName(rs.getString("studentName"));
                cert.setCourseName(rs.getString("courseName"));
                cert.setIssueDate(rs.getDate("issueDate").toLocalDate());
                cert.setStatus(rs.getString("status"));
                list.add(cert);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Certificate getCertificateById(int id) {
        String sql = "SELECT * FROM certificates WHERE certificateId=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Certificate cert = new Certificate();
                cert.setCertificateId(rs.getInt("certificateId"));
                cert.setStudentName(rs.getString("studentName"));
                cert.setCourseName(rs.getString("courseName"));
                cert.setIssueDate(rs.getDate("issueDate").toLocalDate());
                cert.setStatus(rs.getString("status"));
                return cert;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    @Override
    public void updateCertificate(Certificate c) {
        String sql = "UPDATE certificates SET status=? WHERE certificateId=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getStatus());
            ps.setInt(2, c.getCertificateId());
            ps.executeUpdate();
            System.out.println("UPDATED Successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void deleteCertificate(int id) {
        String sql = "DELETE FROM certificates WHERE certificateId=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("DELETED Successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
