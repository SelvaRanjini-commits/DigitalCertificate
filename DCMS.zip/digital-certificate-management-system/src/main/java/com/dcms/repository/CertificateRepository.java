package com.dcms.repository;

import java.util.List;
import com.dcms.model.Certificate;   // <-- THIS LINE WAS MISSING! ADD IT

public interface CertificateRepository {
    void insertCertificate(Certificate certificate);
    List<Certificate> getAllCertificates();
    Certificate getCertificateById(int id);
    void updateCertificate(Certificate certificate);
    void deleteCertificate(int id);
}