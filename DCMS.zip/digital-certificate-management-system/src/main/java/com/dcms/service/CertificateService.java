package com.dcms.service;

import java.util.List;
import com.dcms.model.Certificate;
import com.dcms.exception.CertificateNotFoundException; // ADD THIS

public interface CertificateService {
    void issueCertificate(Certificate certificate);
    List<Certificate> viewAllCertificates();
    Certificate searchCertificate(int id);
    void updateCertificate(Certificate certificate);
    void deleteCertificate(int id);
    void verifyCertificate(int id) throws CertificateNotFoundException; // CHANGE THIS LINE
}