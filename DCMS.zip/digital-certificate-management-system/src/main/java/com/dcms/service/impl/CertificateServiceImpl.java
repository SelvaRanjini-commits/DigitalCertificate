package com.dcms.service.impl;

import com.dcms.model.Certificate;
import com.dcms.repository.CertificateRepository;
import com.dcms.repository.impl.CertificateRepositoryImpl;
import com.dcms.service.CertificateService;
import java.time.LocalDate;
import java.util.List;
import com.dcms.exception.CertificateNotFoundException;
public class CertificateServiceImpl implements CertificateService {

    private CertificateRepository repo = new CertificateRepositoryImpl();

    @Override
    public void issueCertificate(Certificate c) {
        if (c.getStudentName() == null || c.getStudentName().isEmpty()) {
            System.out.println("Student name cannot be empty!");
            return;
        }
        c.setIssueDate(LocalDate.now());
        c.setStatus("ISSUED");
        repo.insertCertificate(c);
    }

    @Override
    public List<Certificate> viewAllCertificates() {
        return repo.getAllCertificates();
    }

    @Override
    public Certificate searchCertificate(int id) {
        return repo.getCertificateById(id);
    }

    @Override
    public void updateCertificate(Certificate c) {
        repo.updateCertificate(c);
    }

    @Override
    public void deleteCertificate(int id) {
        repo.deleteCertificate(id);
    }

    @Override
    public void verifyCertificate(int id) throws CertificateNotFoundException {
        Certificate c = repo.getCertificateById(id);
        if (c != null) {
            System.out.println("Certificate VERIFIED: " + c.getStudentName() + " - " + c.getCourseName());
        } else {
            throw new CertificateNotFoundException("Certificate ID " + id + " NOT FOUND - Invalid!");
        }
    }
}
