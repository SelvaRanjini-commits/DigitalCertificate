package com.dcms.controller;

import com.dcms.model.Certificate;
import com.dcms.service.CertificateService;
import com.dcms.service.impl.CertificateServiceImpl;
import com.dcms.exception.CertificateNotFoundException;
import java.util.List;
import java.util.Scanner;

public class CertificateController {
    private CertificateService service = new CertificateServiceImpl();
    private Scanner sc = new Scanner(System.in);

    public void showMenu() {
        int choice;
        do {
            System.out.println("\n--- Digital Certificate Management ---");
            System.out.println("1. Add Certificate");
            System.out.println("2. View Certificates");
            System.out.println("3. Search Certificate");
            System.out.println("4. Update Certificate");
            System.out.println("5. Delete Certificate");
            System.out.println("6. Verify Certificate");
            System.out.println("7. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1: add(); break;
                case 2: view(); break;
                case 3: search(); break;
                case 4: update(); break;
                case 5: delete(); break;
                case 6: verify(); break;
                case 7: System.out.println("Exiting..."); break;
                default: System.out.println("Invalid choice!");
            }
        } while (choice != 7);
    }

    private void add() {
        System.out.print("Enter Student Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Course Name: ");
        String course = sc.nextLine();
        Certificate c = new Certificate();
        c.setStudentName(name);
        c.setCourseName(course);
        service.issueCertificate(c);
    }

    private void view() {
        List<Certificate> list = service.viewAllCertificates();
        System.out.println("--- All Certificates ---");
        for (Certificate c : list) {
            System.out.println(c.getCertificateId() + " | " + c.getStudentName() + " | " + c.getCourseName() + " | " + c.getIssueDate() + " | " + c.getStatus());
        }
    }

    private void search() {
        System.out.print("Enter Certificate ID: ");
        int id = sc.nextInt(); sc.nextLine();
        Certificate c = service.searchCertificate(id);
        if (c != null) {
            System.out.println("Found: " + c.getStudentName() + " - " + c.getCourseName());
        } else {
            System.out.println("Not Found!");
        }
    }

    private void update() {
        System.out.print("Enter Certificate ID to update: ");
        int id = sc.nextInt(); sc.nextLine();
        System.out.print("Enter new Status (ISSUED/REVOKED): ");
        String status = sc.nextLine();
        Certificate c = new Certificate();
        c.setCertificateId(id);
        c.setStatus(status);
        service.updateCertificate(c);
    }

    private void delete() {
        System.out.print("Enter Certificate ID to delete: ");
        int id = sc.nextInt(); sc.nextLine();
        service.deleteCertificate(id);
    }

    private void verify() {
        System.out.print("Enter Certificate ID to verify: ");
        int id = sc.nextInt(); sc.nextLine();
        try {
            service.verifyCertificate(id);
        } catch (CertificateNotFoundException e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }
}
