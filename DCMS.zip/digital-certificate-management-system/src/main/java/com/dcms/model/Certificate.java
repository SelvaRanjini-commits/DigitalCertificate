package com.dcms.model;

import java.time.LocalDate;

public class Certificate {
    private int certificateId;
    private String studentName;
    private String studentEmail;
    private String courseName;
    private LocalDate issueDate;
    private String status;

    public Certificate() {
    }

    public Certificate(int certificateId, String studentName, String studentEmail, String courseName, LocalDate issueDate, String status) {
        this.certificateId = certificateId;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.courseName = courseName;
        this.issueDate = issueDate;
        this.status = status;
    }

    public int getCertificateId() {
        return certificateId;
    }

    public void setCertificateId(int certificateId) {
        this.certificateId = certificateId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(LocalDate issueDate) {
        this.issueDate = issueDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
