package com.dcms.main;

import com.dcms.controller.CertificateController;

public class MainApp {
    public static void main(String[] args) {
        CertificateController controller = new CertificateController();
        controller.showMenu();
    }
}