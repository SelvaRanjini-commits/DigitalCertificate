package com.dcms.exception;

public class CertificateNotFoundException extends Exception {
    public CertificateNotFoundException(String message) {
        super(message);
    }
}